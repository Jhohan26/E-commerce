// Utilidades de formato y catálogo de estados.

export const ESTADOS = [
  { value: 'PENDIENTE',  label: 'Pendiente',  tone: 'pendiente'  },
  { value: 'EN_PROCESO', label: 'En proceso', tone: 'proceso'    },
  { value: 'PAGADO',     label: 'Pagado',     tone: 'pagado'     },
  { value: 'ENVIADO',    label: 'Enviado',    tone: 'enviado'    },
  { value: 'COMPLETADO', label: 'Completado', tone: 'completado' },
  { value: 'CANCELADO',  label: 'Cancelado',  tone: 'cancelado'  }
];

const ESTADO_MAP = Object.fromEntries(ESTADOS.map(e => [e.value, e]));

export function estadoMeta(value) {
  return ESTADO_MAP[value] || { value, label: value, tone: 'completado' };
}

// Escapa texto antes de insertarlo con innerHTML.
export function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

const moneyFormatter = new Intl.NumberFormat('es-CO', {
  style: 'currency',
  currency: 'COP',
  maximumFractionDigits: 0
});

export function formatMoney(amount) {
  return moneyFormatter.format(Number(amount) || 0);
}

export function formatNumber(n) {
  return new Intl.NumberFormat('es-CO').format(Number(n) || 0);
}

// Devuelve { date: '06 oct 2026', time: '03:35' } a partir de un ISO local.
export function formatDateParts(iso) {
  if (!iso) return { date: '-', time: '' };
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return { date: String(iso), time: '' };
  const day = String(d.getDate()).padStart(2, '0');
  const month = d.toLocaleDateString('es-CO', { month: 'short' }).replace(/\./g, '');
  return {
    date: `${day} ${month} ${d.getFullYear()}`,
    time: d.toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit', hour12: false })
  };
}

export function formatDateTime(iso) {
  const { date, time } = formatDateParts(iso);
  return time ? `${date}, ${time}` : date;
}

export function debounce(fn, wait = 200) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), wait);
  };
}

export function statusChipHtml(value, motivo = null) {
  const meta = estadoMeta(value);
  if (value === 'CANCELADO' && motivo) {
    const isInventario = motivo.toLowerCase().includes('inventario');
    const isPago = motivo.toLowerCase().includes('pago');
    const badgeText = isInventario ? 'Inventario' : (isPago ? 'Pago rechazado' : motivo);
    return `<span class="chip chip-${meta.tone}" title="${escapeHtml(motivo)}" style="display:inline-flex;flex-direction:column;align-items:flex-start;padding:3px 8px;line-height:1.2;">
      <span style="display:inline-flex;align-items:center;gap:5px;">
        <span class="chip-dot" aria-hidden="true"></span>${escapeHtml(meta.label)}
      </span>
      <span style="font-size:0.68rem;font-weight:600;opacity:0.9;margin-top:1px;">(${escapeHtml(badgeText)})</span>
    </span>`;
  }
  return `<span class="chip chip-${meta.tone}"><span class="chip-dot" aria-hidden="true"></span>${escapeHtml(meta.label)}</span>`;
}

// Catálogo dinámico de Clientes (obtenido exclusivamente del Grupo F)
export let CLIENTES_CATALOGO = {};

export function actualizarClientesCatalogo(lista) {
  CLIENTES_CATALOGO = {};
  if (Array.isArray(lista) && lista.length > 0) {
    lista.forEach((c) => {
      CLIENTES_CATALOGO[Number(c.id)] = {
        id: Number(c.id),
        nombre: c.nombre,
        ciudad: c.ciudad || '',
        correo: c.correo || '',
        estado: c.estado,
        activo: c.activo !== false,
        origen: c.origen || 'grupoF'
      };
    });
  }
}

export let PRODUCTOS_CATALOGO = {
  // Catálogo sincronizado exclusivamente con Productos (Grupo G)
  1: { id: 1, nombre: 'MACBOOK',             precio: 2500000, icono: 'laptop',     categoria: 'Electrónica' },
  2: { id: 2, nombre: 'Audífonos Bluetooth', precio: 150000,  icono: 'headphones', categoria: 'Accesorios' },
  3: { id: 3, nombre: 'Camiseta básica',     precio: 35000,   icono: 'box',        categoria: 'Ropa' },
  5: { id: 5, nombre: 'jean azul',           precio: 80000,   icono: 'box',        categoria: 'Ropa' },
  6: { id: 6, nombre: 'Jabon',               precio: 2000,    icono: 'box',        categoria: 'Hogar' },
  7: { id: 7, nombre: 'Zapatera',            precio: 100000,  icono: 'box',        categoria: 'Hogar' },
  8: { id: 8, nombre: 'Mouse Bluetooth',     precio: 65000,   icono: 'mouse',      categoria: 'Accesorios' }
};

export function actualizarProductosCatalogo(lista) {
  if (Array.isArray(lista) && lista.length > 0) {
    PRODUCTOS_CATALOGO = {};
    lista.forEach((p) => {
      PRODUCTOS_CATALOGO[Number(p.id)] = {
        id: Number(p.id),
        nombre: p.nombre,
        precio: Number(p.precio) || 0,
        categoria: p.categoria || 'General',
        icono: p.icono || 'box',
        stock: p.stock
      };
    });
  }
}

export function getClienteInfo(id) {
  return CLIENTES_CATALOGO[Number(id)] || null;
}

export function getClienteNombre(id) {
  const c = CLIENTES_CATALOGO[Number(id)];
  return c ? c.nombre : `Cliente #${id}`;
}

export function getProductoInfo(id) {
  return PRODUCTOS_CATALOGO[Number(id)] || null;
}

export function getProductoNombre(id) {
  const p = PRODUCTOS_CATALOGO[Number(id)];
  return p ? p.nombre : `Producto #${id}`;
}

export function getProductoIcono(id) {
  const p = PRODUCTOS_CATALOGO[Number(id)];
  return `p-${p ? p.icono : 'box'}`;
}

// "Carlos Gómez" -> "CG"
export function iniciales(nombre) {
  return String(nombre || '')
    .split(/\s+/)
    .filter((w) => /^[A-Za-zÁÉÍÓÚÑáéíóúñ]/.test(w))
    .slice(0, 2)
    .map((w) => w[0].toUpperCase())
    .join('') || '#';
}

